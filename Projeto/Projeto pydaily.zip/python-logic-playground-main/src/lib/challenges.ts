// Procedural Python challenge generator.
// Each template produces a fresh challenge with randomized params.

export type Challenge = {
  prompt: string;        // Question shown to user
  code: string;          // Python snippet displayed
  choices: string[];     // 4 multiple-choice options
  answer: string;        // Correct option (must equal one of choices)
  hint: string;          // Concept tag
};

// Helper: pick random integer in [min,max]
const ri = (min: number, max: number) =>
  Math.floor(Math.random() * (max - min + 1)) + min;

// Helper: shuffle array (Fisher-Yates)
const shuffle = <T,>(arr: T[]): T[] => {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
};

// Helper: build distinct distractors near the correct numeric answer
const numericChoices = (correct: number): string[] => {
  const set = new Set<number>([correct]);
  while (set.size < 4) set.add(correct + ri(-5, 5));
  return shuffle([...set]).map(String);
};

// === Template 1: list slicing ===
const tplSlice = (): Challenge => {
  const list = Array.from({ length: ri(5, 8) }, () => ri(1, 9)); // random list
  const a = ri(0, list.length - 2);                              // start index
  const b = ri(a + 1, list.length);                              // end index
  const result = list.slice(a, b);                               // mirror Python slice
  const correct = JSON.stringify(result);                        // serialize as Python list
  // build distractor slices from nearby indices
  const distractors = new Set<string>();
  while (distractors.size < 3) {
    const da = Math.max(0, a + ri(-1, 1));
    const db = Math.min(list.length, b + ri(-1, 1));
    const s = JSON.stringify(list.slice(da, db));
    if (s !== correct) distractors.add(s);
  }
  return {
    prompt: "Qual o output deste código?",
    code: `lst = ${JSON.stringify(list)}\nprint(lst[${a}:${b}])`,
    choices: shuffle([correct, ...distractors]),
    answer: correct,
    hint: "list slicing",
  };
};

// === Template 2: modulo / arithmetic ===
const tplModulo = (): Challenge => {
  const x = ri(10, 99);                  // dividend
  const y = ri(2, 9);                    // divisor
  const correct = x % y;                 // Python % matches JS % for positives
  return {
    prompt: "Qual o resultado?",
    code: `print(${x} % ${y})`,
    choices: numericChoices(correct),
    answer: String(correct),
    hint: "modulo",
  };
};

// === Template 3: list comprehension ===
const tplComprehension = (): Challenge => {
  const n = ri(4, 7);                                                // upper bound
  const result = Array.from({ length: n }, (_, i) => i)              // range(n)
    .filter((i) => i % 2 === 0)                                      // even filter
    .map((i) => i * i);                                              // square
  const correct = JSON.stringify(result);
  // distractors: variations of the comprehension semantics
  const v1 = JSON.stringify(Array.from({ length: n }, (_, i) => i * i));
  const v2 = JSON.stringify(Array.from({ length: n }, (_, i) => i).filter((i) => i % 2 === 0));
  const v3 = JSON.stringify(Array.from({ length: n }, (_, i) => i).filter((i) => i % 2 !== 0).map((i) => i * i));
  const pool = [v1, v2, v3].filter((s) => s !== correct);
  return {
    prompt: "Qual o output?",
    code: `print([i*i for i in range(${n}) if i%2==0])`,
    choices: shuffle([correct, ...pool.slice(0, 3)]),
    answer: correct,
    hint: "list comprehension",
  };
};

// === Template 4: complete a function ===
const tplComplete = (): Challenge => {
  // function: sum of even numbers in a list
  const list = Array.from({ length: ri(4, 6) }, () => ri(1, 9));
  const expected = list.filter((n) => n % 2 === 0).reduce((s, n) => s + n, 0);
  const correct = "if n % 2 == 0";
  const distractors = ["if n % 2 == 1", "if n / 2 == 0", "if n % 2"];
  return {
    prompt: `Complete a função para que soma_pares(${JSON.stringify(list)}) retorne ${expected}:`,
    code: `def soma_pares(lst):\n    total = 0\n    for n in lst:\n        ___:\n            total += n\n    return total`,
    choices: shuffle([correct, ...distractors]),
    answer: correct,
    hint: "função / condicional",
  };
};

// === Template 5: string indexing ===
const tplString = (): Challenge => {
  const words = ["python", "lovable", "termo", "wordle", "snake", "logic"];
  const w = words[ri(0, words.length - 1)];
  const i = ri(0, w.length - 1);
  const j = ri(i + 1, w.length);
  const correct = JSON.stringify(w.slice(i, j));
  const distractors = new Set<string>();
  while (distractors.size < 3) {
    const di = Math.max(0, i + ri(-1, 1));
    const dj = Math.min(w.length, j + ri(-1, 1));
    const s = JSON.stringify(w.slice(di, dj));
    if (s !== correct) distractors.add(s);
  }
  return {
    prompt: "Qual o output?",
    code: `s = "${w}"\nprint(s[${i}:${j}])`,
    choices: shuffle([correct, ...distractors]),
    answer: correct,
    hint: "string slicing",
  };
};

// === Template 6: len of dict ===
const tplDict = (): Challenge => {
  const n = ri(3, 6);
  const pairs = Array.from({ length: n }, (_, k) => `"k${k}": ${ri(1, 9)}`).join(", ");
  const correct = n;
  return {
    prompt: "Qual o output?",
    code: `d = {${pairs}}\nprint(len(d))`,
    choices: numericChoices(correct),
    answer: String(correct),
    hint: "dict / len",
  };
};

const templates = [tplSlice, tplModulo, tplComprehension, tplComplete, tplString, tplDict];

// Generate a fresh challenge, optionally avoiding the previous code text
export const nextChallenge = (prevCode?: string): Challenge => {
  for (let i = 0; i < 6; i++) {
    const c = templates[Math.floor(Math.random() * templates.length)]();
    if (c.code !== prevCode) return c;
  }
  return templates[0]();
};
