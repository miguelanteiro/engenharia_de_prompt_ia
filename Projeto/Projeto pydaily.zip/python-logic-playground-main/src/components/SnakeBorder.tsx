// Fixed full-viewport SVG; the rect perimeter is the snake's track.
// Animation lives in styles.css (.snake-path keyframes).
export function SnakeBorder() {
  return (
    <svg
      className="pointer-events-none fixed inset-0 z-0 h-full w-full"
      preserveAspectRatio="none"
      viewBox="0 0 100 100"
      aria-hidden
    >
      {/* Static dim border for context */}
      <rect x="1" y="1" width="98" height="98" rx="1.2"
        fill="none" stroke="var(--color-border)" strokeWidth="0.3" />
      {/* Snake body */}
      <rect x="1" y="1" width="98" height="98" rx="1.2"
        className="snake-path" pathLength="2000" vectorEffect="non-scaling-stroke" />
      {/* Trailing tail */}
      <rect x="1" y="1" width="98" height="98" rx="1.2"
        className="snake-path-2" pathLength="2000" vectorEffect="non-scaling-stroke" />
    </svg>
  );
}
